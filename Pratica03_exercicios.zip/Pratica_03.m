clear all; close all; clc;

% Vetor de Eb/No em dB
EbNo_dB = 0:10;
Eb = 1;     % Energia de bit normalizada
EbNo = 10.^(EbNo_dB/10);

% Numero de bits por EbNo simulado
N_b = [1e4 1e4 1e4 1e4 1e4 1e4 1e5 1e5 1e6 1e6 5e6];
% Vetor de Erros por EbNo simulado
Erros = zeros(size(EbNo));
% Vetor de Prob. de Erro por EbNo
Pe = zeros(size(EbNo));

% La�o principal
for eb = 1: length(EbNo)% 1 � 11
    disp(['EbNo = ', num2str(EbNo_dB(eb)), ' dB ']);
    % Valor de No para cada valor de Eb/No
    No= 1/EbNo(eb);
    % Vetor de bits transmitidos
    b = (rand(1, N_b(eb)) > 0.5);
    % Sinaliza��o antipodal  [1 -> 1] [0 -> -1]
    b_pol = 2*b -1;
    % Vetor de ruido AWGN com vari�ncia No/20
    n = sqrt(No/2)*randn(1,N_b(eb));
    % Sinal recebido (sinal + ruido AWGN)
    % Equivale � sa�da do amostrador do filtro casado
    r = b_pol + n;
    % bits estimados [se<0=0  se>0=1]
    b_chap = r > 0;
    % Erros para cada EbNo modulo para nao resultar zero -1+1-> |-1|+|1|
    Erros(eb) = sum(abs(b - b_chap));
    % Probabilidade de Erro
    Pe(eb) = Erros(eb)/N_b(eb);
end

% Probabilidade de Erro Te�rica
Pe_teo = qf(sqrt(2*EbNo));


%%%%%%%%%%% GRAFICOS %%%%%%%%%%
% Gr�fico da curva te�rica (linha azul)
semilogy(EbNo_dB, Pe_teo);
hold on; % "Pausa" a tela do gr�fico
% Gr�fico da curva simulada (asterisco em vermelho)
semilogy(EbNo_dB,Pe,'r*');

xlabel('EbNo [dB]');
ylabel('Probabilidade de Erro');
legend('EbNo', 'Erros');
